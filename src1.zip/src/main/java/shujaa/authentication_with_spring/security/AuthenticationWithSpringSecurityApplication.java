package shujaa.authentication_with_spring.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenticationWithSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationWithSpringSecurityApplication.class, args);
	}

}
