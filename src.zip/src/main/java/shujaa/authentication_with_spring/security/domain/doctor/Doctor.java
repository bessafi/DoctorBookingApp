package shujaa.authentication_with_spring.security.domain.doctor;

import jakarta.persistence.*;
import lombok.*;
import shujaa.authentication_with_spring.security.entity.User;

import java.time.*;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "doctors", indexes = {
        @Index(name="idx_doctor_user", columnList = "user_id", unique = true)
})
public class Doctor {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    private String firstName;
    private String lastName;
    private String phone;
    private String specialty;

    /** IANA TZ, e.g., "Africa/Algiers" */
    private String timezone = "Africa/Algiers";

    /** Usually "primary" for the user’s main calendar */
    private String calendarId = "primary";

    /** Google OAuth tokens */
    @Column(length = 2048)
    private String googleAccessToken;

    @Column(length = 2048)
    private String googleRefreshToken;

    private Instant googleTokenExpiry;

    /** Working hours + slot size used to propose slots (local to timezone) */
    private LocalTime workStart = LocalTime.of(9, 0);
    private LocalTime workEnd   = LocalTime.of(17, 0);
    private Integer slotMinutes = 30;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    void prePersist() {
        createdAt = LocalDateTime.now();
        updatedAt = createdAt;
    }
    @PreUpdate
    void preUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
