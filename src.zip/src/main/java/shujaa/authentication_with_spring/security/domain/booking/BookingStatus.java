package shujaa.authentication_with_spring.security.domain.booking;

public enum BookingStatus {
    CONFIRMED, CANCELED
}
