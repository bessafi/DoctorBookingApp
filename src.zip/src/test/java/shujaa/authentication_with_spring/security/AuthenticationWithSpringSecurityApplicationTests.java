package shujaa.authentication_with_spring.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationWithSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
